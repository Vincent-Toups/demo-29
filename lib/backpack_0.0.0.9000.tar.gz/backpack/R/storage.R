library(stringr);
library(readr);
library(magrittr);

#' Get the local filesystem reference for a piece of BACPAC Data.
#'
#' @param project - the BACPAC project to which the data belongs.
#' @param container - the container type for the data
#' @param file - the file from the storage location
#' @return a local filesystem reference
#' @export
#' @examples
#' bacpac_data_location("test_data","Canonical","DM.csv")
bacpac_data_location <- function(project, container, file){
    switch(Sys.info()[['sysname']],
           Windows= {sprintf("C:\\mnt\\containers\\%s_%s\\%s",project, container, file)},
           Linux  = {sprintf("/mnt/containers/%s_%s/%s",project, container, file)},
           Darwin = {sprintf("/mnt/containers/%s_%s/%s",project, container, file)});
}

parse_location <- function(s){
    r <- stringr::str_split(s,":")[[1]];
    if(length(r)!=3){
        stop(sprintf("BACPAC data locations consist of three parts - a project, a container and a file like this:
project:container:some-file/path.csv. Instead we got %s.", s));
    }
    as.list(r);
}

#' Load a csv file from BACPAC storage 
#'
#' @param location in <project>:<container>:<file> notation
#' @return the CSV data in a tibble
#' @export
#' @examples
#' bacpac_csv("test_data:Canonical:DM.csv")
bacpac_csv <- function(s){
    parsed <- parse_location(s);
    actual_location <- do.call(bacpac_data_location, parsed);
    readr::read_csv(actual_location);
}

