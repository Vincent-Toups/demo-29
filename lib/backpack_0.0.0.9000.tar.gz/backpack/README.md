BACPAC Backpack
===============

This is a collection of utilities in multiple programming languages
meant to facilitate analysis of BACPAC related data in its common
format. The Backpack is distributed under the terms of the GNU GPLv3
license (a copy of which is included with this repository).

Development
===========

There is a dockerfile for development of the package.

